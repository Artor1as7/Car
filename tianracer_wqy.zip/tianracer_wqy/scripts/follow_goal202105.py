#!/usr/bin/env python
import roslib
import rospy
import socket
import time
from ackermann_msgs.msg import AckermannDrive

test_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
target_x = 1
target_y = 0


max_angle = 0.5    # the max angle is 0.5
max_speed = 1    # the max speed is 1
k_p_speed = 1.5
k_p_angle = 0.5

dt = 0.1 
precision = 0.05

# v0 = 0
ackermann = AckermannDrive()
ackermann.speed = 0.0
ackermann.steering_angle = 0.0
ackermann_cmd_pub = rospy.Publisher('/tianracer/ackermann_cmd', AckermannDrive, queue_size=5)
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("127.0.0.1", 6666))

def get_goal_position():
    """
    docstring
    """
    msgs = s.recv(1000).replace('(', '').replace(')', '').replace(' ', '').split(',')    
    x = float(msgs[2])
    y = float(msgs[0])
    return x, y

## 在此处收到目标x，y的值

def get_v0(history_distance, T):
    """
    docstring
    """
    if -1 in history_distance:
        return 0
    else:
        v0 = (history_distance[-1] - history_distance[0]) * T + ackermann.speed
        return v0
    ## v0 =  v_first_car



## 获取 初始位置
def __init__(self, x1=0.0, y1=0.0, yaw1=0.0, v1=0.0):
        self.x1 = x1
        self.y1 = y1
        self.yaw1 = yaw1
        self.v1 = v1


## 获取 行进中的位置
def update(state, a, delta):
    state.x1 = state.x1 + state.v1 * math.cos(state.yaw) * dt
    state.y1 = state.y1 + state.v1 * math.sin(state.yaw) * dt
    state.yaw1 = state.yaw1 + state.v1 / L * math.tan(delta) * dt
    state.v1 = state.v + a * dt
    return state


def pure_pursuit_control(state, cx, cy, pind):

    ind = calc_target_index(state, cx, cy)

    if pind >= ind:
        ind = pind

    if ind < len(cx):
        tx = cx[ind]
        ty = cy[ind]
    else:
        tx = cx[-1]
        ty = cy[-1]
        ind = len(cx) - 1

    alpha = math.atan2(ty - state.y, tx - state.x) - state.yaw

    if state.v < 0:  # back
        alpha = math.pi - alpha

    Lf = k * state.v + Lfc

    delta = math.atan2(2.0 * L * math.sin(alpha) / Lf, 1.0)

    if delta > np.pi / 6.0:
        delta = np.pi / 6.0
    elif delta < - np.pi / 6.0:
        delta = - np.pi / 6.0

    dx = x - target_x
    dy = y - target_y


    d_speed = dx * k_p_speed + v0
    #d_speed = (math.sqrt(x*x+y*y)-1)*k_p_speed + v0
    if d_speed > max_speed:
        speed = max_speed
    elif d_speed < -max_speed:
        speed = -max_speed
    else:
        speed = d_speed

    if (not is_zero(angle, max_angle, 0.1)) and is_zero(speed, max_speed, 0.05):
        speed = -0.5


    return delta,speed,ind



def calc_target_index(state, cx, cy):
    # 搜索最临近的路点
    dx = [state.x - icx for icx in cx]
    dy = [state.y - icy for icy in cy]
    d = [abs(math.sqrt(idx ** 2 + idy ** 2)) for (idx, idy) in zip(dx, dy)]
    ind = d.index(min(d))
    L = 0.0

    Lf = k * state.v + Lfc

    while Lf > L and (ind + 1) < len(cx):
        dx = cx[ind + 1] - cx[ind]
        dy = cx[ind + 1] - cx[ind]
        L += math.sqrt(dx ** 2 + dy ** 2)
        ind += 1

    return ind


def got_path(x,y):
    
    dx = x - target_x
    dy = y - target_y
    length = (dy^2 + dx^2 )^0.5
    PointNum = dx//precision
    ##将整个路程分为多个点
    i = 0

    aax = {}
    aay = {}
   
    Turn_number = 0
    zkf = 0
    for i in range(PointNum): 
        aax[Turn_number] = dx*i/PointNum
        aay[Turn_number] = dy*i/PointNum
        bbx = list(aax.values())
        bby = list(aay.values())
        i += 1
 
    return bbx,bby



if __name__ == "__main__":
    rospy.init_node('ros_talker')
    cnt = 0
    T = 20
    r = rospy.Rate(T)
    f = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/test.txt','a')
    f.write('\n%s' % test_time)
    #history_distance = [-1,-1,-1]
    try:
        #f.write('\n%s' % test_time)
        while not rospy.is_shutdown():
            x1, y1 = get_goal_position()
            # r.sleep()
            x2, y2 = get_goal_position()
            x = (x1 + x2) / 2
            y = (y1 + y2) / 2
            #history_distance.append(x)
            #history_distance.pop(0)
            #v0 = get_v0(history_distance, T)


            cx,cy = got_path(x,y)

            angle,speed,_ = pure_pursuit_control(state, cx, cy, pind)


            ackermann.speed = speed
            ackermann.steering_angle = angle
	        #rospy.loginfo("x, y, speed, angle: %s, %s, %s, %s" % (x, y, speed, angle))
            ackermann_cmd_pub.publish(ackermann)
            cnt += 1
            print(cnt,x,y,speed,angle)
            f.write('\nx, y, speed, angle: %s, %s, %s, %s' % (x, y, speed, angle))
            # r.sleep()
            

    except Exception as e:
        print(e)

    finally:
        ackermann = AckermannDrive()
        ackermann.speed = 0.0
        ackermann.steering_angle = 0.0
        ackermann_cmd_pub.publish(ackermann)
        s.close()
        f.close()