def case0(x,y):
    print("case0")

def case1():
    print("case1")

def case2():
    print("case2")

def case3():
    print("case3")

cases = {0: case0,
        1: case1,
        2: case2,
        3: case3
        }
case = 10
cases.get(case,case0)(1,2)