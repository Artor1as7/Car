#!/usr/bin/env python
import roslib
import rospy
import socket
import time
import math
import numpy
from ackermann_msgs.msg import AckermannDrive

test_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
L_d = 1
alpha_d = 0
max_angle = 0.5    # the max angle is 0.5
max_speed = 1    # the max speed is 1
T = 0.1          #sampling time  
k_p_l = 0.5
k_p_alpha = 0.3
T_i_alpha = 100
T_d_alpha = 0
e = [0,0,0]
u = [0,0,0]
d = 0.13 # half length of the vehicle
v0 = 0
ackermann = AckermannDrive()
ackermann.speed = 0.0
ackermann.steering_angle = 0.0
ackermann_cmd_pub = rospy.Publisher('/tianracer/ackermann_cmd', AckermannDrive, queue_size=5)
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("127.0.0.1", 6666))

def get_goal_position():
    """
    docstring
    """
    msgs = s.recv(1000).replace('(', '').replace(')', '').replace(' ', '').split(',') 
    x = float(msgs[4])
    y = float(msgs[2])
    return x, y

def get_v0(history_distance, T):
    """
    docstring
    """
    if -1 in history_distance:
        return 0
    else:
        v_first_car = (history_distance[-1] - history_distance[0]) * T + ackermann.speed
        return v_first_car

def get_command(x1, y1, x2, y2, v0):
    """
    docstring
    """
    angle = math.pi/18
    
    return angle

if __name__ == "__main__":
    rospy.init_node('ros_talker')
    T = 20
    r = rospy.Rate(T)
    f = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/test.txt','a')
    f.write('\n%s' % test_time)
    #history_distance = [-1,-1,-1]
    try:
        #f.write('\n%s' % test_time)
        while not rospy.is_shutdown():
            x1, y1 = get_goal_position()
	    r.sleep()
	    x2, y2 = get_goal_position()
	    x = (x1 + x2) / 2
	    y = (y1 + y2) / 2
            #history_distance.append(x)
            #history_distance.pop(0)
            #v0 = get_v0(history_distance, T)
            angle = get_command(x1, y1, x2, y2, v0)
            #ackermann.speed = speed
            ackermann.steering_angle = angle
	    #rospy.loginfo("x, y, speed, angle: %s, %s, %s, %s" % (x, y, speed, angle))
            ackermann_cmd_pub.publish(ackermann)
	    r.sleep()
            
    except Exception as e:
        print(e)

    finally:
        ackermann = AckermannDrive()
        ackermann.speed = 0.0
        ackermann.steering_angle = 0.0
        ackermann_cmd_pub.publish(ackermann)
	s.close()
        f.close()
