#!/usr/bin/env python
import roslib
import rospy
import socket
import time
import math
import numpy as np
from ackermann_msgs.msg import AckermannDrive

test_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
target_x = 1
target_y = 0

Kp = 1.0 

height = 0  
weight = 0
start = (0, 0)  
goal = (0, 0)  

road = []  
wall = []  
closeList = []  
openList = [] 
dirt = {}  

TT = 30


max_speed = 0.7      # the max speed is 0.7


Lfc = 0.3
k = 0.1 
dt = 0.2
L = 0.36
v0 = 0

valuedistance = {}  
finalList = []  

distance_per_point = 0.08

ackermann = AckermannDrive()
ackermann.speed = 0.0
ackermann.steering_angle = 0.0
ackermann_cmd_pub = rospy.Publisher('/tianracer/ackermann_cmd', AckermannDrive, queue_size=5)

def read_Map():
    ifile = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/map3.txt')
    global height, weight, start, goal  
    fileLine = ifile.readline()  
    while len(fileLine) > 0:
        weight = len(fileLine.split('\n')[0])  
        for i in range(0, weight):
            if 's' == fileLine[i]:  
                start = (height, i)
                road.append((height, i))
            if 'g' == fileLine[i]:  
                goal = (height, i)
                road.append((height, i))
            if '#' == fileLine[i]:  
                road.append((height, i))
            if 'b' == fileLine[i]:  
                wall.append((height, i))
        height += 1
        fileLine = ifile.readline()

def change_father_value(value, new_value, dis):
    
    if new_value != dirt[value] and (new_value in openList or new_value in closeList):
        value_distance = start_distance(value) + goal_distance(value)
        new_value_distance = start_distance(new_value) + goal_distance(value)
        if round(new_value_distance + dis, 1) < round(value_distance, 1): 
            # print(new_value_distance, dis1, value_distance)
            # print(new_value,value)
            dirt[value] = new_value  
        
def start_distance(value):
    father_value = dirt[value]
    if abs(value[0] - father_value[0]) == 1 and abs(value[1] - father_value[1]):  
        start_distance = 1.4
    else:
        start_distance = 1
    while father_value is not start:  
        value = father_value
        father_value = dirt[father_value]
        if abs(value[0] - father_value[0]) == 1 and abs(value[1] - father_value[1]):  
            start_distance += 1.4
        else:
            start_distance += 1

    return start_distance

def traversal(father_value):
    closeList.append(father_value)

    if father_value == goal: 
        return
    x = father_value[0]
    y = father_value[1]

    add_openList_and_dirt((x + 1, y), father_value)

    if (x + 1, y) in road and (x, y + 1) in road:  
        add_openList_and_dirt((x + 1, y + 1), father_value, )
    
    add_openList_and_dirt((x, y + 1), father_value)
    
    if (x - 1, y) in road and (x, y + 1) in road:  
        add_openList_and_dirt((x - 1, y + 1), father_value)
    
    add_openList_and_dirt((x - 1, y), father_value)

    if (x - 1, y) in road and (x, y - 1) in road:  
        add_openList_and_dirt((x - 1, y - 1), father_value)
    
    add_openList_and_dirt((x, y - 1), father_value)
    
    if (x + 1, y) in road and (x, y - 1) in road:  
        add_openList_and_dirt((x + 1, y - 1), father_value)

def add_openList_and_dirt(value, father_value):
    if value in road and value not in closeList:  
        if value not in openList:  
            openList.append(value)  
            dirt[value] = father_value  
            
            valuedistance[value] = round(start_distance(value) + goal_distance(value), 1)
        
        if value in openList and dirt[value] != start:  
        
            x = value[0]
            y = value[1]
            change_father_value(value, (value[0], value[1] + 1), 1)  
            if (x, y + 1) in road and (x + 1, y) in road:   
                change_father_value(value, (value[0] + 1, value[1] + 1), 1.4)  
            change_father_value(value, (value[0] + 1, value[1]), 1)  
            if (x, y - 1) in road and (x + 1, y) in road:  
                change_father_value(value, (value[0] + 1, value[1] - 1), 1.4)  
            change_father_value(value, (value[0], value[1] - 1), 1)  
            if (x, y - 1) in road and (x - 1, y) in road: 
                change_father_value(value, (value[0] - 1, value[1] - 1), 1.4)  
            change_father_value(value, (value[0] - 1, value[1]), 1)  
            if (x, y + 1) in road and (x - 1, y) in road:  
                change_father_value(value, (value[0] - 1, value[1] + 1), 1.4)  
            valuedistance[value] = round(start_distance(value) + goal_distance(value), 1)  

def goal_distance(value):
	
    tmp = abs(abs(value[0] - goal[0]) - abs(value[1] - goal[1]))
    if tmp == 0:
    
        goal_distance = abs(value[0] - goal[0]) * 1.4
    else:
    	
        goal_distance = tmp + min(abs(value[0] - goal[0]), abs(value[1] - goal[1])) * 1.4
    return goal_distance

def recursion(value):
    finalList.append(value)
    if value != start:
        recursion(dirt[value])

def Torngzhour(node0, node1, node2):
    
    # if (node0[0] == node1[0] and node0[0] == node2[0]) or (node0[1] == node1[1] and node0[1] == node2[1]):
    #     return True
   
    if (node1[0] - node0[0] == node2[0] - node1[0]) and (node1[1] - node0[1] == node2[1] - node1[1]):
        return True
    else:
        return False

def ZhaangAih(node1, node2):
 
    max_y = max(node1[0], node2[0])
    min_y = min(node1[0], node2[0])

    max_x = max(node1[1], node2[1])
    min_x = min(node1[1], node2[1])
    hit = []

    hit.append(node1)
    hit.append(node2)
    for x in range(min_x, max_x + 1):
        y = (node1[0] - node2[0]) / (node1[1] - node2[1]) * (x - node2[1]) + node2[0]
    
        hit.append((round((y - 0.5)), x))
        hit.append((round((y + 0.5)), x))

    for y in range(min_y, max_y + 1):
        x = (node1[1] - node2[1]) / (node1[0] - node2[0]) * (y - node2[0]) + node2[1]
  
        hit.append((y, round(x - 0.5)))
        hit.append((y, round(x + 0.5)))

    for i in range(len(hit)):
        if hit[i] in wall:
          
            return True
    return False


class VehicleState:

    def __init__(self, x=0.0, y=0.0, yaw=0.0, v=0.0):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.v = v


def get_v0(history_distance, T):
    """
    docstring
    """
    if -1 in history_distance:
        return 0
    else:
        v0 = (history_distance[-1] - history_distance[0]) * T + ackermann.speed
        return v0
    ## v0 =  v_first_car

def PControl(target, current):
    a = Kp * (target - current)

    return a


## got the first position
def __init__(self, x1=0.0, y1=0.0, yaw1=0.0, v1=0.0):
        self.x1 = x1
        self.y1 = y1
        self.yaw1 = yaw1
        self.v1 = v1


## got the runnning position
def update(state, a, delta):

    state.x = state.x + state.v * math.cos(state.yaw) * dt
    state.y = state.y + state.v * math.sin(state.yaw) * dt
    state.yaw = state.yaw + state.v / L * math.tan(delta) * dt
    state.v = state.v + a * dt

    return state


def pure_pursuit_control(state, cx, cy, pind):

    ind = calc_target_index(state, cx, cy)

    if pind >= ind:
        ind = pind

    if ind < len(cx):
        tx = cx[ind]
        ty = cy[ind]
    else:
        tx = cx[-1]
        ty = cy[-1]
        ind = len(cx) - 1

    alpha = math.atan2(ty - state.y, tx - state.x) - state.yaw

    if state.v < 0:  # back
        alpha = math.pi - alpha

    Lf = k * state.v + Lfc

    delta = math.atan2(2.0 * L * math.sin(alpha) / Lf, 1.0)

    # if delta > np.pi / 5.0:
    #     delta = np.pi / 5.0
    
    # elif delta < - np.pi / 5.0:
    #     delta = - np.pi / 5.0

    if delta > 0.6:
        delta = 0.6
    
    elif delta < - 0.6:
        delta = - 0.6

    return delta, ind


def is_zero(test_number, max_number, tolerance):
    if abs(test_number)/max_number < tolerance:
        return True
    else:
        return False


def calc_target_index(state, cx, cy):
    # nearest point

    dx = [state.x - icx for icx in cx]
    dy = [state.y - icy for icy in cy]
    
    d = [abs(math.sqrt(idx ** 2 + idy ** 2)) for (idx, idy) in zip(dx, dy)]
    ind = d.index(min(d))
    L = 0.0

    Lf = k * state.v + Lfc

    while Lf > L and (ind + 1) < len(cx):
        dx = cx[ind + 1] - cx[ind]
        dy = cy[ind + 1] - cy[ind]
        L += math.sqrt(dx ** 2 + dy ** 2)
        ind += 1

    return ind


def got_path(new_path):
    ax = {}
    ay = {}
    aax = {}
    aay = {}
    
    new_num = 0
    for cha in range(len(new_path)):   
        kk = new_path[cha]
        ax[cha] = kk[0]*3.0/10
        ay[cha] = kk[1]*3.0/10
        print(ax[cha],type(ax[cha]))
        cha += 1
    bx = list(ax.values())
    by = list(ay.values())
    
    print('bxby',bx,by)
    #return bx,by

    cha = 0
    chaa = 0
    new_number = 0
    
    Turn_number = 0
    zkf = 0
    for chaa in range(len(new_path)-1): 
        difx = bx[chaa]
        dify = by[chaa]
        diffx = bx[chaa+1]
        diffy = by[chaa+1]
        ddx = diffx-difx
        ddy = diffy-dify 
        d = abs(math.sqrt(ddx * ddx + ddy * ddy))

        new_number = d//distance_per_point
        new_number = round(new_number)
     
        ccha = 0
        new_num = d//distance_per_point + new_num
        new_num = int(new_num)
        # print("new_num",type(new_num),new_num)
        # print("zkf",type(zkf),zkf)
        
       
        # print("ddx ddy d nm nnm are ",ddx,ddy,d,new_num,new_number)
        # Check
       
        for Turn_number in range(zkf,new_num):
            # print(Turn_number)
            aax[Turn_number] = dify + ddy*ccha/new_number
            aay[Turn_number] = (difx + ddx*ccha/new_number)*-1
            ccha += 1
            Turn_number += 1 
        bbx = list(aax.values())
        bby = list(aay.values())
        # print(bbx,bby)

        zkf =  Turn_number
        
        chaa += 1
 
    return bbx,bby

def got_speed(ispeed,cx):
    lencx = len(cx)
    print("lencx",lencx)
    
    if ispeed in range(30,lencx-30):
        speed = max_speed
    elif ispeed in range(30):
        speed = ispeed*max_speed/30
    else:
        speed = max_speed*(lencx - ispeed)/30 

    return speed


if __name__ == "__main__":

    read_Map()  
    traversal(start)  
    while goal not in openList:  
        min_distance_value = min(valuedistance, key=lambda x: valuedistance[x])  
        valuedistance.pop(min_distance_value)  
        openList.remove(min_distance_value)  
        traversal(min_distance_value)  

        if not openList:  
            print("none")
            quit()

    if goal in openList:
        recursion(goal)
    
    path = finalList
    path.reverse()

    T = []
    size = len(path)
    for i in range(size):
       
        if i == 0 or i == size - 1:
            continue
        else:
            if not Torngzhour(path[i - 1], path[i], path[i + 1]):
                T.append(path[i])
    print("T is ", T)

    need_count = 0
    size = len(T)
    while need_count < size:

        need_count = 0
        size = len(T)
        i = 0
        new_path = path

        while i < len(T):
            if i == 0:
                last_node = start
            else:
                last_node = T[i - 1]
            if i == len(T) - 1:
                next_node = goal
            else:
                next_node = T[i + 1]
            if not ZhaangAih(last_node, next_node):
                T.pop(i)
            else:
                i += 1
                need_count += 1
    # print("T = ", T)

    new_path = [start]

    for i in range(len(T)):
        new_path.append(T[i])
    new_path.append(goal)

    new_path = new_path
    print("new_path ", new_path)
    #change the rate of the map

    rospy.init_node('ros_talker')
    T = 10
    r = rospy.Rate(T)
    
    f = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/test.txt','a')
    f.write('\n%s' % test_time)
    
    

    #history_distance = [-1,-1,-1]
    cx,cy = got_path(new_path)
    # state = VehicleState(x=cx[0], y=cy[0], yaw= np.pi/-2, v=0.0)
    state = VehicleState(x=cx[0], y=cy[0], yaw= 0, v=0.0)
    #f.write('\n%s' % test_time)
    if not rospy.is_shutdown():
        x = [state.x]
        y = [state.y]
        yaw = [state.yaw]
        v = [state.v]
        t = [0.0]
        target_speed = 0.8
        target_ind = calc_target_index(state, cx, cy)
        lastIndex = len(cx) - 1
        timee = 0.0
        final_speed = {}
        final_angle = {}
        iiii = 0

        while TT >= timee and lastIndex > target_ind:
            ai = PControl(target_speed, state.v)
            angle, target_ind = pure_pursuit_control(state, cx, cy, target_ind)
            print('angle',angle)
            final_angle[iiii] = angle
            state = update(state, ai, angle)

            timee = timee + dt

            final_speed[iiii] = state.v

            x.append(state.x)
            y.append(state.y)
            yaw.append(state.yaw)
            v.append(state.v)
            t.append(timee) 
            iiii += 1
            # speed = got_speed(ispeed,cx)
        final_angle = list(final_angle.values())
        final_speed = list(final_speed.values())
        print("FinS&A",len(final_angle),len(final_speed),final_angle,final_speed)    
        
        cnt = 0

        for cnt in range(len(final_angle)):

            ackermann.speed = final_speed[cnt]
            ackermann.steering_angle = final_angle[cnt]
	        #rospy.loginfo("x, y, speed, angle: %s, %s, %s, %s" % (x, y, speed, angle))
            ackermann_cmd_pub.publish(ackermann)
            f.write('\nx, y, speed, angle: %s, %s, %s, %s' % (x, y, ackermann.speed, ackermann.steering_angle))
            cnt += 1            
            # f.write('\nx, y, speed, angle: %s, %s, %s, %s' % (x, y, speed, angle))
            # r.sleep()
            print("cnt",cnt,ackermann.speed,ackermann.steering_angle)
            time.sleep(dt)
           
	        #rospy.loginfo("x, y, speed, angle: %s, %s, %s, %s" % (x, y, speed, angle))
            

        ackermann = AckermannDrive()
        ackermann.speed = 0.0
        ackermann.steering_angle = 0.0
        ackermann_cmd_pub.publish(ackermann)
        f.close()