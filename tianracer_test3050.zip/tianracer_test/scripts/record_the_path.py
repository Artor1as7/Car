#!/usr/bin/env python
import rospy
import time
from geometry_msgs.msg import PoseWithCovarianceStamped
test_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

def callback(data):
    # rospy.loginfo(rospy.get_caller_id() + "I heard %s", data.data)
    x = data.pose.pose.position.x
    y = data.pose.pose.position.y
    f.write('\nx, y: %s, %s' % (x, y))
    
def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener_record', anonymous=True)

    rospy.Subscriber("amcl_pose", PoseWithCovarianceStamped, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    f = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/record_path.txt','a')
    f.write('\n%s' % test_time)
    listener()
    f.close()