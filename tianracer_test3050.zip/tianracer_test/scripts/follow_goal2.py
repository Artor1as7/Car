#!/usr/bin/env python
import roslib
import rospy
import socket
import time
import math
import numpy
from ackermann_msgs.msg import AckermannDrive

test_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
L_d = 0.5
PHI_d = 0
max_angle = 0.5    # the max angle is 0.5
max_speed = 1    # the max speed is 1
T = 0.05          #sampling time  
K_p_l = 1
K_p_phi = 0.1
theta_f = [0,0]
d = 0.13 # half length of the vehicle
v0 = 0
last_y = 0
last_x = 1
flag = 0
ackermann = AckermannDrive()
ackermann.speed = 0.0
ackermann.steering_angle = 0.0
ackermann_cmd_pub = rospy.Publisher('/tianracer/ackermann_cmd', AckermannDrive, queue_size=5)
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.settimeout(0.06)
s.connect(("127.0.0.1", 6666))

def get_goal_position():
    """
    docstring
    """
    try:
        msgs = s.recv(1000).replace('(', '').replace(')', '').replace(' ', '').split(',') 
	x = float(msgs[4])
	y = float(msgs[2])
	flag = 1
    except Exception as e:
	flag = 0
	y = last_y
        x = last_x
    finally:
    	return x, y, flag

def get_v0(history_distance, T):
    """
    docstring
    """
    if -1 in history_distance:
        return 0
    else:
        v_first_car = (history_distance[-1] - history_distance[0]) * T + ackermann.speed
        return v_first_car

def get_command(x, y, v0):
    """
    docstring
    """

    #x = (x1+x2) / 2
    #y = (y1+y2) / 2
    phi = math.atan(y/x)
  
    #if y1 == y2:
	#alpha = phi
    #else:
	#alpha = phi - math.atan((x2-x1)/(y2-y1))
    l = math.sqrt(x*x+y*y)
    #e[2] = e[1]
    #e[1] = e[0]
    #e[0] = alpha_d-alpha
    #u[0] = -math.sin(phi)/d*k_p_l*(L_d-l) + l/d*math.cos(phi)*(k_p_alpha*(e[0]-e[1])+T/T_i_alpha*e[0]+T_d_alpha/T*(e[0]-2*e[1]+e[2]))
    #u[2] = u[1]
    #u[1] = u[2] + u[0]
    #angle_input = u[1]
    speed_input = -1/math.cos(phi)*K_p_l*(L_d-l)
    if speed_input > max_speed:
        speed = max_speed
    elif speed_input < -max_speed:
        speed = -max_speed
    else:
        speed = speed_input
    # the max speed is 1
    if phi < 5.0/180*math.pi and phi > -5.0/180*math.pi:
    	omega_input = K_p_phi*(PHI_d-phi)
    elif abs(-math.tan(phi)/l*K_p_l*(L_d-l)) > abs(K_p_phi*(PHI_d-phi)):
	omega_input = K_p_phi*(PHI_d-phi)
    else:
    	omega_input = -math.tan(phi)/l*K_p_l*(L_d-l)+K_p_phi*(PHI_d-phi)
    theta_f[1] = theta_f[0]+omega_input*T
    angle_input = theta_f[1]
    if angle_input > max_angle:
        angle = max_angle
    elif angle_input < -max_angle:
        angle = -max_angle
    else:
        angle = angle_input
    theta_f[0] = angle
    # the max angle is 0.5
    #if speed < 0.05 and abs(alpha_d-alpha) > 0.05:
	#speed = 0.07*numpy.sign(l-L_d)
    #if abs(L_d-l) < 0.02 and abs(alpha_d-alpha) < 0.05:
	#speed = 0
	#angle = 0
    return speed, angle, phi

if __name__ == "__main__":
    rospy.init_node('ros_talker')
    T = 20
    r = rospy.Rate(T)
    f = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/test.txt','a')
    f.write('\n%s' % test_time)
    #history_distance = [-1,-1,-1]
    try:
        #f.write('\n%s' % test_time)
        while not rospy.is_shutdown():
            x, y, flag = get_goal_position()
	    r.sleep()
	    #x2, y2, flag2 = get_goal_position()
	    #x = (x1 + x2) / 2
	    #y = (y1 + y2) / 2
            last_x = x
	    last_y = y
            l = math.sqrt(x*x+y*y)
            #history_distance.append(x)
            #history_distance.pop(0)
            #v0 = get_v0(history_distance, T)
	    if flag == 1:
		speed, angle, phi = get_command(x, y, v0)
	    else:
		speed, angle, phi = get_command(x, y, v0)
		speed = 0
            ackermann.speed = speed
            ackermann.steering_angle = angle
	    #rospy.loginfo("x, y, speed, angle, left, right: %s, %s, %s, %s, %s, %s" % (x, y, speed, angle, -math.tan(phi)/l*K_p_l*(l-L_d), -K_p_phi*(phi-PHI_d)))
            ackermann_cmd_pub.publish(ackermann)
            print("x, y, speed, angle, left, right: %s, %s, %s, %s, %s, %s" % (x, y, speed, angle, -math.tan(phi)/l*K_p_l*(L_d-l), K_p_phi*(PHI_d-phi)))
            #f.write('\nx1, y1, x2, y2, x, y, speed, angle, phi, alpha, angle_input %s, %s, %s, %s, %s, %s, %s, %s, %s, %s %s' % (x1, y1, x2, y2, x, y, speed, angle, phi, alpha, angle_input))
	    r.sleep()
            
    except Exception as e:
        print(e)

    finally:
        ackermann = AckermannDrive()
        ackermann.speed = 0.0
        ackermann.steering_angle = 0.0
        ackermann_cmd_pub.publish(ackermann)
	s.close()
        f.close()
