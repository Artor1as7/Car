#!/usr/bin/env python
import roslib
import rospy
import socket
import time
from ackermann_msgs.msg import AckermannDrive

test_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
target_x = 1
target_y = 0
max_angle = 0.5    # the max angle is 0.5
max_speed = 1    # the max speed is 1
k_p_speed = 1.5
dt = 0.1 
precision = 0.05
# v0 = 0
ackermann = AckermannDrive()
ackermann.speed = 0.0
ackermann.steering_angle = 0.0
ackermann_cmd_pub = rospy.Publisher('/tianracer/ackermann_cmd', AckermannDrive, queue_size=5)
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("127.0.0.1", 6666))

def get_goal_position():
    """
    docstring
    """
    msgs = s.recv(1000).replace('(', '').replace(')', '').replace(' ', '').split(',')    
    x = float(msgs[2])
    y = float(msgs[0])
    return x, y

## 在此处收到目标x，y的值

def get_v0(history_distance, T):
    """
    docstring
    """
    if -1 in history_distance:
        return 0
    else:
        v0 = (history_distance[-1] - history_distance[0]) * T + ackermann.speed
        return v0
    ## v0 =  v_first_car



def get_command(x, y, v0):
    """
    docstring
    """
    dx = x - target_x
    dy = y - target_y
    length = (dy^2 + dx^2 )^0.5
    PointNum = dx/precision
    ##将整个路程分为多个点
    i = 0
    while i <= PointNum :
      cx(i) = dx*i/PointNum
      cy(i) = dx*i/PointNum
      i = i+1



## 获取 初始位置
def __init__(self, x1=0.0, y1=0.0, yaw1=0.0, v1=0.0):
        self.x1 = x1
        self.y1 = y1
        self.yaw1 = yaw1
        self.v1 = v1



## 获取 行进中的位置
def update(state, a, delta):
    state.x1 = state.x1 + state.v1 * math.cos(state.yaw) * dt
    state.y1 = state.y1 + state.v1 * math.sin(state.yaw) * dt
    state.yaw1 = state.yaw1 + state.v1 / L * math.tan(delta) * dt
    state.v1 = state.v + a * dt
    return state




def calc_target_index(state, cx, cy):
    # 搜索最临近的路点
    # 在上一步中需要将车的行进路径变为点
    dx = [state.x - icx for icx in cx]
    dy = [state.y - icy for icy in cy]
    d = [abs(math.sqrt(idx ** 2 + idy ** 2)) for (idx, idy) in zip(dx, dy)]
    ind = d.index(min(d))

    return ind




if __name__ == "__main__":
    rospy.init_node('ros_talker')
    T = 10
    r = rospy.Rate(T)
    f = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/test.txt','a')
    f.write('\n%s' % test_time)
    #history_distance = [-1,-1,-1]
    try:
        #f.write('\n%s' % test_time)
        while not rospy.is_shutdown():
            x, y = get_goal_position()
            #history_distance.append(x)
            #history_distance.pop(0)
            #v0 = get_v0(history_distance, T)
            speed, angle = get_command(x, y, v0)
            ackermann.speed = speed
            ackermann.steering_angle = angle
	    rospy.loginfo("x, y, speed, angle: %s, %s, %s, %s" % (x, y, speed, angle))
            ackermann_cmd_pub.publish(ackermann)
            f.write('\nx, y, speed, angle: %s, %s, %s, %s' % (x, y, speed, angle))
            r.sleep()

    except Exception as e:
        print(e)

    finally:
        ackermann = AckermannDrive()
        ackermann.speed = 0.0
        ackermann.steering_angle = 0.0
        ackermann_cmd_pub.publish(ackermann)
	    s.close()
        f.close()