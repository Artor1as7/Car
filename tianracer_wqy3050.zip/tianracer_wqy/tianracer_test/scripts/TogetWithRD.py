import numpy as np
import math
import matplotlib.pyplot as plt

height = 0  
weight = 0  # 
start = (0, 0)  # 
goal = (0, 0)  #

road = []  
wall = []  
closeList = []  
openList = []  #
dirt = {}  # 

valuedistance = {}  #    
finalList = []  #  



k = 0.1     # 
Lfc = 0.3   # 
Kp = 3.0    #
dt = 0.1    # 
L = 0.4     #

distance_per_point = 0.05  #

height = 0  # 
weight = 0  # 


def read_Map():
    
    ifile = open('/home/tianbot/tianbot_ws/src/tianracer/tianracer_test/scripts/map3.txt','r')  # 

    global height, weight, start, goal  # 
    fileLine = ifile.readline()  # 
    while len(fileLine) > 0:
        weight = len(fileLine.split('\n')[0])  # 
        for i in range(0, weight):
            if 's' == fileLine[i]:  # 
                start = (height, i)
                road.append((height, i))
            if 'g' == fileLine[i]:  # 
                goal = (height, i)
                road.append((height, i))
            if '#' == fileLine[i]:  # 
                road.append((height, i))
            if 'b' == fileLine[i]:  # 
                wall.append((height, i))
        height += 1
        fileLine = ifile.readline()



def goal_distance(value):
	
    tmp = abs(abs(value[0] - goal[0]) - abs(value[1] - goal[1]))
    if tmp == 0:
    
        goal_distance = abs(value[0] - goal[0]) * 1.4
    else:
    	#
        goal_distance = tmp + min(abs(value[0] - goal[0]), abs(value[1] - goal[1])) * 1.4
    return goal_distance


# 
def start_distance(value):
    father_value = dirt[value]
    if abs(value[0] - father_value[0]) == 1 and abs(value[1] - father_value[1]):  # 
        start_distance = 1.4
    else:
        start_distance = 1
    while father_value is not start:  # 
        value = father_value
        father_value = dirt[father_value]
        if abs(value[0] - father_value[0]) == 1 and abs(value[1] - father_value[1]):  # 
            start_distance += 1.4
        else:
            start_distance += 1

    return start_distance



def change_father_value(value, new_value, dis):
    
    if new_value != dirt[value] and (new_value in openList or new_value in closeList):
        value_distance = start_distance(value) + goal_distance(value)
        new_value_distance = start_distance(new_value) + goal_distance(value)
        if round(new_value_distance + dis, 1) < round(value_distance, 1):  
            # print(new_value_distance, dis1, value_distance)
            # print(new_value,value)
            dirt[value] = new_value  



def add_openList_and_dirt(value, father_value):
    if value in road and value not in closeList:  
        if value not in openList:  
            openList.append(value)  
            dirt[value] = father_value  
            
            valuedistance[value] = round(start_distance(value) + goal_distance(value), 1)
      
        if value in openList and dirt[value] != start:  
            
            x = value[0]
            y = value[1]
            change_father_value(value, (value[0], value[1] + 1), 1)  # 
            if (x, y + 1) in road and (x + 1, y) in road:  
                change_father_value(value, (value[0] + 1, value[1] + 1), 1.4)  # 
            change_father_value(value, (value[0] + 1, value[1]), 1)  # 
            if (x, y - 1) in road and (x + 1, y) in road:  # 
                change_father_value(value, (value[0] + 1, value[1] - 1), 1.4)  # 
            change_father_value(value, (value[0], value[1] - 1), 1)  # 
            if (x, y - 1) in road and (x - 1, y) in road:  # 
                change_father_value(value, (value[0] - 1, value[1] - 1), 1.4)  # 
            change_father_value(value, (value[0] - 1, value[1]), 1)  #
            if (x, y + 1) in road and (x - 1, y) in road:  # 
                change_father_value(value, (value[0] - 1, value[1] + 1), 1.4)  # 
            valuedistance[value] = round(start_distance(value) + goal_distance(value), 1)  # 



def traversal(father_value):
    closeList.append(father_value)

    if father_value == goal:  
        return
    x = father_value[0]
    y = father_value[1]
    
    #
    add_openList_and_dirt((x + 1, y), father_value)
    #
    if (x + 1, y) in road and (x, y + 1) in road:  # 
        add_openList_and_dirt((x + 1, y + 1), father_value, )
    # 
    add_openList_and_dirt((x, y + 1), father_value)
    # 
    if (x - 1, y) in road and (x, y + 1) in road:  # 
        add_openList_and_dirt((x - 1, y + 1), father_value)
    # 
    add_openList_and_dirt((x - 1, y), father_value)
    # 
    if (x - 1, y) in road and (x, y - 1) in road:  # 
        add_openList_and_dirt((x - 1, y - 1), father_value)
    # 
    add_openList_and_dirt((x, y - 1), father_value)
    # 
    if (x + 1, y) in road and (x, y - 1) in road:  # 
        add_openList_and_dirt((x + 1, y - 1), father_value)



def recursion(value):
    finalList.append(value)
    if value != start:
        recursion(dirt[value])

def Torngzhour(node0, node1, node2):
    #
    if (node1[0] - node0[0] == node2[0] - node1[0]) and (node1[1] - node0[1] == node2[1] - node1[1]):
        return True
    else:
        return False


def ZhaangAih(node1, node2):
 
    max_y = max(node1[0], node2[0])
    min_y = min(node1[0], node2[0])

    max_x = max(node1[1], node2[1])
    min_x = min(node1[1], node2[1])
    hit = []

    hit.append(node1)
    hit.append(node2)
    for x in range(min_x, max_x + 1):
        y = (node1[0] - node2[0]) / (node1[1] - node2[1]) * (x - node2[1]) + node2[0]
    
        hit.append((round((y - 0.5)), x))
        hit.append((round((y + 0.5)), x))

    for y in range(min_y, max_y + 1):
        x = (node1[1] - node2[1]) / (node1[0] - node2[0]) * (y - node2[0]) + node2[1]
  
        hit.append((y, round(x - 0.5)))
        hit.append((y, round(x + 0.5)))

    for i in range(len(hit)):
        if hit[i] in wall:
          
            return True
    return False




class VehicleState:

    def __init__(self, x=0.0, y=0.0, yaw=0.0, v=0.0):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.v = v


def update(state, a, delta):

    state.x = state.x + state.v * math.cos(state.yaw) * dt
    state.y = state.y + state.v * math.sin(state.yaw) * dt
    state.yaw = state.yaw + state.v / L * math.tan(delta) * dt
    state.v = state.v + a * dt

    return state
def PControl(target, current):
    a = Kp * (target - current)

    return a


def pure_pursuit_control(state, cx, cy, pind):

    ind = calc_target_index(state, cx, cy)

    if pind >= ind:
        ind = pind

    if ind < len(cx):
        tx = cx[ind]
        ty = cy[ind]
    else:
        tx = cx[-1]
        ty = cy[-1]
        ind = len(cx) - 1

    alpha = math.atan2(ty - state.y, tx - state.x) - state.yaw

    if state.v < 0:  # back
        alpha = math.pi - alpha

    Lf = k * state.v + Lfc

    delta = math.atan2(2.0 * L * math.sin(alpha) / Lf, 1.0)

    if delta > np.pi / 6.0:
        delta = np.pi / 6.0
    elif delta < - np.pi / 6.0:
        delta = - np.pi / 6.0

    return delta, ind

def calc_target_index(state, cx, cy):
    
    dx = [state.x - icx for icx in cx]
    dy = [state.y - icy for icy in cy]
    d = [abs(math.sqrt(idx ** 2 + idy ** 2)) for (idx, idy) in zip(dx, dy)]
    ind = d.index(min(d))
    L = 0.0

    Lf = k * state.v + Lfc

    while Lf > L and (ind + 1) < len(cx):
        dx = cx[ind + 1] - cx[ind]
        dy = cx[ind + 1] - cx[ind]
        L += math.sqrt(dx ** 2 + dy ** 2)
        ind += 1

    return ind


#def got_path(new_path):



#    i = 0

#    ax.append(len(new_path))
#    ay.append(len(new_path))
#    while i < len(new_path):
#      point = new_path[i]
#      ax[i] = point[0]
#      ay[i] = point[1]
#      return ax,ay



def got_path(new_path):
    ax = {}
    ay = {}
    aax = {}
    aay = {}
    
    new_num = 0
    for cha in range(len(new_path)):   
        kk = new_path[cha]
        ax[cha] = kk[0]
        ay[cha] = kk[1]
        cha += 1
    bx = list(ax.values())
    by = list(ay.values())
    
    #print(bx,by)
    #return bx,by

    cha = 0
    chaa = 0
    new_number = 0
   
  
    Turn_number = 0
    zkf = 0
    for chaa in range(len(new_path)-1): 
        difx = bx[chaa]
        dify = by[chaa]
        diffx = bx[chaa+1]
        diffy = by[chaa+1]
        ddx = diffx-difx
        ddy = diffy-dify 
        d = abs(math.sqrt(ddx * ddx + ddy * ddy))

        new_number = d//distance_per_point
        new_number = round(new_number)
     
        ccha = 0
        new_num = d//distance_per_point + new_num
        new_num = round(new_num)
    
        print("ddx ddy d nm nnm are ",ddx,ddy,d,new_num,new_number)
   
       
        for Turn_number in range(zkf,new_num):
            print(Turn_number)
            aax[Turn_number] = dify + ddy*ccha/new_number
            aay[Turn_number] = (difx + ddx*ccha/new_number)*-1
            ccha += 1
            Turn_number += 1 
            bbx = list(aax.values())
            bby = list(aay.values())
            # print(bbx,bby)

        zkf =  Turn_number
       
        chaa += 1
 
    return bbx,bby


if __name__ == '__main__':
    read_Map()  

    traversal(start)  #
    while goal not in openList:  
        min_distance_value = min(valuedistance, key=lambda x: valuedistance[x])  
        valuedistance.pop(min_distance_value)  #
        openList.remove(min_distance_value)  # 
        traversal(min_distance_value)  # 

        if not openList:  # 
            print("无方案")
            quit()



   
    if goal in openList:
        recursion(goal)



   
    path = finalList
    path.reverse()
    print("path = ", path)

 
    T = []
    size = len(path)
    for i in range(size):
      
        if i == 0 or i == size - 1:
            continue
        else:
            if not Torngzhour(path[i - 1], path[i], path[i + 1]):
                T.append(path[i])
    print("T is ", T)

   
    need_count = 0
    size = len(T)
    while need_count < size:

   
        need_count = 0
        size = len(T)
        i = 0
        new_path = path

        while i < len(T):
            if i == 0:
                last_node = start
            else:
                last_node = T[i - 1]
            if i == len(T) - 1:
                next_node = goal
            else:
                next_node = T[i + 1]
            if not ZhaangAih(last_node, next_node):
                T.pop(i)
            else:
                i += 1
                need_count += 1
    print("T = ", T)

    new_path = [start]

    for i in range(len(T)):
        new_path.append(T[i])
    new_path.append(goal)
    print("new_path ", new_path)
    

###################################################################################################################################################################
    

    cx,cy = got_path(new_path)

    target_speed = 10 / 3.6  # [m/s]

    T = 100.0  #

    #

    state = VehicleState(x=cx[0], y=cy[0], yaw= math.pi, v=0.0)

    lastIndex = len(cx) - 1
    time = 0.0
    x = [state.x]
    y = [state.y]
    yaw = [state.yaw]
    v = [state.v]
    t = [0.0]
    target_ind = calc_target_index(state, cx, cy)

    while T >= time and lastIndex > target_ind:
        ai = PControl(target_speed, state.v)
        di, target_ind = pure_pursuit_control(state, cx, cy, target_ind)
        state = update(state, ai, di)

        time = time + dt

        x.append(state.x)
        y.append(state.y)
        yaw.append(state.yaw)
        v.append(state.v)
        t.append(time)

        plt.cla()
        plt.plot(cx, cy, ".r", label="course")
        plt.plot(x, y, "-b", label="trajectory")
        # plt.plot(cx[target_ind], cy[target_ind], "go", label="target")
        plt.axis("equal")
        plt.grid(True)        
        plt.pause(0.001)
  
    print(cx,cy)


    
    


   






